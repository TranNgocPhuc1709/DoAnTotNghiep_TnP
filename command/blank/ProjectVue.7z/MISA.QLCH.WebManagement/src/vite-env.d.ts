/// <reference types="vite/client" />

declare module "qlch_control/*"{}
declare module "qlch_base/*"{}
