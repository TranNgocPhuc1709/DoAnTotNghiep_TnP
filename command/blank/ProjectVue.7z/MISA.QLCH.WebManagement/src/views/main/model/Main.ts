import IMain from "./IMain";

export default class Main {
    /**
     * Constructor
     */
    constructor(input?: IMain) {
        const me = this;
        if (input && input?.title) {
            me.title = input.title;
        }
    }

    title?: string

}