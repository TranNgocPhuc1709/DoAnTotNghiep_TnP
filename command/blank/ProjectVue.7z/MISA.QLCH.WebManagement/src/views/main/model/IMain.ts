export default interface IMain {
    title?: string
}