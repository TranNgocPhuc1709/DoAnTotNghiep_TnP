import { createRouter, createWebHistory, RouteRecordRaw } from 'vue-router'

const routes: Array<RouteRecordRaw> = [
    {
        path: '/',
        name: 'default',
        redirect: '/main/invoice'
    },
    {
        path: '/main',
        name: 'main',
        component: () => import('@src/views/main/Main.vue'),
        children: [
            {
                path: 'invoice',
                name: 'invoice',
                component: () => import('@src/views/invoice-list-dictionary/InvoiceListDictionary.vue'),
            }
        ]
    }

]

const router = createRouter({
    history: createWebHistory(import.meta.env.BASE_URL),
    routes
})


export default router
